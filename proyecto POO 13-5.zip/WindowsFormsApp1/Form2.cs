﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        string datos = "DatosLogin.csv";

        List<comprador> lista1 = new List<comprador>();
        List<vendedor> lista2 = new List<vendedor>();
        List<admin> lista3 = new List<admin>();

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(datos, FileMode.OpenOrCreate, FileAccess.Read);
            using (StreamReader sr = new StreamReader(fs))
            {
                string linea = sr.ReadLine();
                string[] li = "";
                while(linea != null)
                {
                    linea = sr.ReadLine();
                    string prioridad = linea[2].ToString();
                    if(prioridad == "1")
                    {
                        comprador uncomprador = new comprador();
                        lista1.Add(uncomprador);
                        linea = sr.ReadLine();
                    }
                    else if(prioridad == "2")
                    {
                        vendedor unvendedor = new vendedor(linea[0], linea[1]);
                        lista2.Add(unvendedor);
                        linea = sr.ReadLine();
                    }
                    else if(prioridad == "3")
                    {
                        admin unadmin = new admin();
                        lista3.Add(unadmin);
                        linea = sr.ReadLine();
                    }
                }

                string usuario = txtUsuario.Text;
                string contra = txtContra.Text;

                foreach(var pepito in lista1)
                {
                    if()
                }

            }
        }
    }
}
