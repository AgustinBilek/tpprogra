﻿namespace WindowsFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reclamosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hacerReclamoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historialDeReclamosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historialDeMensajesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unloginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revisarReclamosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.puntuacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.puntuarVendedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.puntuacionesDadasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.administradorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaVendedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.puntuacionesRecibidasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reclamosToolStripMenuItem,
            this.puntuacionesToolStripMenuItem,
            this.administradorToolStripMenuItem,
            this.unloginToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reclamosToolStripMenuItem
            // 
            this.reclamosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hacerReclamoToolStripMenuItem,
            this.historialDeReclamosToolStripMenuItem,
            this.historialDeMensajesToolStripMenuItem,
            this.revisarReclamosToolStripMenuItem});
            this.reclamosToolStripMenuItem.Name = "reclamosToolStripMenuItem";
            this.reclamosToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.reclamosToolStripMenuItem.Text = "Reclamos";
            this.reclamosToolStripMenuItem.Click += new System.EventHandler(this.reclamosToolStripMenuItem_Click_1);
            // 
            // hacerReclamoToolStripMenuItem
            // 
            this.hacerReclamoToolStripMenuItem.Name = "hacerReclamoToolStripMenuItem";
            this.hacerReclamoToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.hacerReclamoToolStripMenuItem.Text = "Hacer reclamo";
            // 
            // historialDeReclamosToolStripMenuItem
            // 
            this.historialDeReclamosToolStripMenuItem.Name = "historialDeReclamosToolStripMenuItem";
            this.historialDeReclamosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.historialDeReclamosToolStripMenuItem.Text = "Historial de reclamos";
            // 
            // historialDeMensajesToolStripMenuItem
            // 
            this.historialDeMensajesToolStripMenuItem.Name = "historialDeMensajesToolStripMenuItem";
            this.historialDeMensajesToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.historialDeMensajesToolStripMenuItem.Text = "Reclamos solucionados";
            this.historialDeMensajesToolStripMenuItem.Click += new System.EventHandler(this.historialDeMensajesToolStripMenuItem_Click);
            // 
            // unloginToolStripMenuItem
            // 
            this.unloginToolStripMenuItem.Name = "unloginToolStripMenuItem";
            this.unloginToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.unloginToolStripMenuItem.Text = "Unlogin";
            // 
            // revisarReclamosToolStripMenuItem
            // 
            this.revisarReclamosToolStripMenuItem.Name = "revisarReclamosToolStripMenuItem";
            this.revisarReclamosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.revisarReclamosToolStripMenuItem.Text = "Revisar reclamos";
            // 
            // puntuacionesToolStripMenuItem
            // 
            this.puntuacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.puntuarVendedorToolStripMenuItem,
            this.puntuacionesDadasToolStripMenuItem1,
            this.puntuacionesRecibidasToolStripMenuItem});
            this.puntuacionesToolStripMenuItem.Name = "puntuacionesToolStripMenuItem";
            this.puntuacionesToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.puntuacionesToolStripMenuItem.Text = "Puntuaciones";
            this.puntuacionesToolStripMenuItem.Click += new System.EventHandler(this.usuarioToolStripMenuItem_Click);
            // 
            // puntuarVendedorToolStripMenuItem
            // 
            this.puntuarVendedorToolStripMenuItem.Name = "puntuarVendedorToolStripMenuItem";
            this.puntuarVendedorToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.puntuarVendedorToolStripMenuItem.Text = "Puntuar vendedor";
            // 
            // puntuacionesDadasToolStripMenuItem1
            // 
            this.puntuacionesDadasToolStripMenuItem1.Name = "puntuacionesDadasToolStripMenuItem1";
            this.puntuacionesDadasToolStripMenuItem1.Size = new System.Drawing.Size(196, 22);
            this.puntuacionesDadasToolStripMenuItem1.Text = "Puntuaciones dadas";
            // 
            // administradorToolStripMenuItem
            // 
            this.administradorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listaUsuariosToolStripMenuItem,
            this.listaVendedoresToolStripMenuItem});
            this.administradorToolStripMenuItem.Name = "administradorToolStripMenuItem";
            this.administradorToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.administradorToolStripMenuItem.Text = "Administrador";
            // 
            // listaUsuariosToolStripMenuItem
            // 
            this.listaUsuariosToolStripMenuItem.Name = "listaUsuariosToolStripMenuItem";
            this.listaUsuariosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listaUsuariosToolStripMenuItem.Text = "Lista usuarios";
            // 
            // listaVendedoresToolStripMenuItem
            // 
            this.listaVendedoresToolStripMenuItem.Name = "listaVendedoresToolStripMenuItem";
            this.listaVendedoresToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listaVendedoresToolStripMenuItem.Text = "Lista vendedores";
            // 
            // puntuacionesRecibidasToolStripMenuItem
            // 
            this.puntuacionesRecibidasToolStripMenuItem.Name = "puntuacionesRecibidasToolStripMenuItem";
            this.puntuacionesRecibidasToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.puntuacionesRecibidasToolStripMenuItem.Text = "Puntuaciones recibidas";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form4";
            this.Text = "Sistema de Reclamos";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reclamosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hacerReclamoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historialDeReclamosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historialDeMensajesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unloginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revisarReclamosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem puntuacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem puntuarVendedorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem puntuacionesDadasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem administradorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaVendedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem puntuacionesRecibidasToolStripMenuItem;
    }
}