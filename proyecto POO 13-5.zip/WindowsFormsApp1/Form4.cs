﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void reclamosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void historialDeMensajesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void puntuacionesDadasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void usuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void reclamosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }
    }
}
